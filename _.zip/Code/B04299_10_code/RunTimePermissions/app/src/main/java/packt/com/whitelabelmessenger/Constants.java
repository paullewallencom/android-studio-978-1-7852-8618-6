package packt.com.whitelabelmessenger;

/**
 * Created by mike on 01-09-15.
 */
public class Constants {

    public static boolean isTestSMS = false;
}
