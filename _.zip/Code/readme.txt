Chapter        Code present
1                  No
2                  yes
3                  yes
4                  yes
5                  yes
6                  yes
7                  yes
8                  yes
9                  yes
10                 yes